# Como aplicar no seu perfil

1. Abra o repositório de perfil `Luiz-Gabriel01/Luiz-Gabriel01`.
2. Substitua o `README.md` pelo arquivo deste pacote.
3. Crie a pasta `.github/workflows/` e adicione `profile-3d.yml`.
4. Adicione `.github/profile-3d-gold.json`.
5. Faça commit/push.
6. Vá em **Actions → GitHub Profile 3D Contrib → Run workflow** e execute uma vez.
7. Depois da primeira execução, o arquivo `profile-3d-contrib/profile-gold.svg` será criado automaticamente.
8. O workflow voltará a gerar o gráfico todos os dias às 03:00 no horário de Recife.

Observação:
- Isso personaliza a visualização das contribuições dentro do README.
- O calendário nativo de contribuições do GitHub, exibido abaixo do perfil, continua com o visual padrão do GitHub.
- Atualize também o campo "Website" do perfil, que ainda aponta para o portfólio antigo, para `https://luizgabrielportfolio.vercel.app/`.
